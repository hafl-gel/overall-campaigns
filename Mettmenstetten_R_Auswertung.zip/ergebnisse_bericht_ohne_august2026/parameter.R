list(root = "/Users/stefan/git", excel = "/Users/stefan/Documents/0 - MSc HAFL/MA/documents/Korrektur_Emissionen_Mettmenstetten_neue-Kalibration.xlsx", 
    out = "ergebnisse_bericht_ohne_august2026", cycles = 8.5, 
    animals_per_place = 1, offset_method = "cumulative_endpoint", 
    fit_points = 8, max_extrapolation_days = 4, season_weights = c(winter = 0.25, 
    transition = 0.5, summer = 0.25))
